import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";

type DimensionKey = "D" | "R" | "E" | "A" | "M";

type Option = {
  id: string;
  text: string;
  dims: DimensionKey[];
  // "Surprising" picks raise Originality; boundary-crossing picks max it out.
  surprising?: boolean;
  boundary?: boolean;
};

type FutureTier = "realistic" | "unlikely" | "impossible";

type Domain = Option & { futures: Record<FutureTier, string> };

type Archetype = {
  number: string;
  name: string;
  rePath: string;
  hook: string;
  portrait: string[];
  edge: string;
  growingEdge: string;
  actions: string[];
  workbook: string;
  day21: string;
};

// Order matters: it breaks ties between dimensions.
const dimensionKeys: DimensionKey[] = ["D", "R", "E", "A", "M"];

const dimensionNames: Record<DimensionKey, { full: string; short: string }> = {
  D: { full: "Deep Nature Wisdom", short: "Rootedness" },
  R: { full: "Restorative Technology", short: "Systems Belief" },
  E: { full: "Embodied Belonging", short: "Collective Ground" },
  A: { full: "Architects of Awe", short: "Generative Imagination" },
  M: { full: "Mutual Abundance", short: "Abundance Orientation" },
};

// Part 1 — Baseline instincts. Self-perception only; not used for the archetype.
const baselineStatements: { dimension: DimensionKey; text: string }[] = [
  { dimension: "D", text: "When I think about the future, I feel like there's a place in it for me." },
  { dimension: "R", text: "I believe broken systems can be redesigned, not just managed." },
  { dimension: "E", text: "When I imagine building something new, I think about who else belongs in the room." },
  { dimension: "A", text: "I can picture a future that doesn't exist yet and feel genuinely excited by it." },
  { dimension: "M", text: "I believe there is enough — room, resources, imagination — for the futures I want to see." },
];

// Q01 — The Inheritance (Remember)
const inheritanceWords: Option[] = [
  { id: "a way of seeing", text: "a way of seeing", dims: ["D"] },
  { id: "a song", text: "a song", dims: ["E"] },
  { id: "a practice", text: "a practice", dims: ["D", "M"] },
  { id: "a language", text: "a language", dims: ["R"] },
  { id: "a recipe", text: "a recipe", dims: ["E"] },
  { id: "a name", text: "a name", dims: ["M"] },
  { id: "a question", text: "a question", dims: ["R"], surprising: true },
  { id: "a permission", text: "a permission", dims: ["A"], surprising: true },
  { id: "a fire", text: "a fire", dims: ["A"], surprising: true },
  { id: "a memory", text: "a memory", dims: ["D"] },
  { id: "a relationship", text: "a relationship", dims: ["E"] },
  { id: "a knowing", text: "a knowing", dims: ["D"], surprising: true },
  { id: "a wound healed", text: "a wound healed", dims: ["M"], surprising: true },
  { id: "a door", text: "a door", dims: ["R"], surprising: true },
  { id: "something with no name yet", text: "something with no name yet", dims: ["A"], boundary: true },
];

// Q02 — The Letter (Reinvision)
const letterOptions: Option[] = [
  { id: "A", text: "“The earth knew what it was doing. We just had to listen.”", dims: ["D"] },
  { id: "B", text: "“We had the tools to fix it. Some of us used them.”", dims: ["R"] },
  { id: "C", text: "“We were better together than we knew.”", dims: ["E"] },
  { id: "D", text: "“The most important thing was never what we built — it was what we dared to imagine.”", dims: ["A"] },
  { id: "E", text: "“There was always enough. We just had to stop pretending there wasn't.”", dims: ["M"], surprising: true },
  { id: "F", text: "“The stories we carried — those were the most important thing.”", dims: ["D", "E"], surprising: true },
];

// Q03 — The Broken Thing (Retrace). Only the Community futures come from the v4 copy;
// the other 15 are drafts pending review.
const brokenDomains: Domain[] = [
  {
    id: "economy",
    text: "The economy — it doesn't work for most people",
    dims: ["M", "R"],
    futures: {
      realistic: "Local businesses and co-ops get a real shot. Money starts circulating closer to home.",
      unlikely: "Work is redesigned so that time, care, and rest count as wealth.",
      impossible: "No one has to earn the right to a dignified life. It's simply where everyone starts.",
    },
  },
  {
    id: "environment",
    text: "The environment — we're running out of time",
    dims: ["D"],
    futures: {
      realistic: "Every neighborhood plants something. Cities get a little greener every year.",
      unlikely: "Rivers, forests, and oceans are given legal rights — and the courts uphold them.",
      impossible: "Humans become a keystone species. Wherever we live, the land gets healthier.",
    },
  },
  {
    id: "technology",
    text: "Technology — it's moving faster than we can handle",
    dims: ["R"],
    futures: {
      realistic: "Communities get a real say in the tools that shape their lives.",
      unlikely: "Technology is designed to give people their time and attention back.",
      impossible: "Every tool we build is measured by one question: did it make us more human?",
    },
  },
  {
    id: "community",
    text: "Community — people feel more alone than ever",
    dims: ["E"],
    futures: {
      realistic: "Neighborhoods start knowing each other again. Block by block.",
      unlikely: "Cities are redesigned around belonging, not efficiency.",
      impossible: "Loneliness becomes as treatable as hunger. Because we decided it should be.",
    },
  },
  {
    id: "culture",
    text: "Culture — we've lost the ability to imagine differently",
    dims: ["A"],
    futures: {
      realistic: "Artists and storytellers are funded like the essential workers they are.",
      unlikely: "Every public decision begins with an act of imagination.",
      impossible: "Children grow up and keep their genius. 98% stays 98%.",
    },
  },
  {
    id: "future",
    text: "The future itself — it doesn't feel like mine",
    dims: ["D", "M"],
    futures: {
      realistic: "More people start to see a place for themselves in what comes next.",
      unlikely: "Every person is taught, from childhood, that the future is something they help write.",
      impossible: "The future stops being something that happens to us. We remember we're the ones making it.",
    },
  },
];

const futureTiers: FutureTier[] = ["realistic", "unlikely", "impossible"];
const temporalityByTier: Record<FutureTier, number> = { realistic: 1, unlikely: 3, impossible: 5 };

// Q04 — The Connection (Reclaim)
const connectionOptions: Option[] = [
  { id: "A", text: "The wisdom of elders and the questions of children", dims: ["D", "E"] },
  { id: "B", text: "A broken neighborhood and the resources it already has", dims: ["R", "M"] },
  { id: "C", text: "People who will never meet but need each other", dims: ["E"] },
  { id: "D", text: "A feeling that has no name and the art that could hold it", dims: ["A"], surprising: true },
  { id: "E", text: "The economy we have and the one that could exist", dims: ["M", "R"] },
  { id: "F", text: "The past that was forgotten and the future being built", dims: ["D", "A"], surprising: true },
];

// Q05 — The Empty Block (Reembody). Archive, library, and playground aren't coded in v4;
// they're assigned D, R, and E here pending review.
const blockWords: Option[] = [
  { id: "garden", text: "garden", dims: ["D"] },
  { id: "archive", text: "archive", dims: ["D"], surprising: true },
  { id: "portal", text: "portal", dims: ["A"], surprising: true },
  { id: "lab", text: "lab", dims: ["R"] },
  { id: "sanctuary", text: "sanctuary", dims: ["D"], surprising: true },
  { id: "market", text: "market", dims: ["E", "M"] },
  { id: "school", text: "school", dims: ["M"] },
  { id: "stage", text: "stage", dims: ["A"] },
  { id: "forest", text: "forest", dims: ["D"] },
  { id: "playground", text: "playground", dims: ["E"] },
  { id: "clinic", text: "clinic", dims: ["R"] },
  { id: "shrine", text: "shrine", dims: ["A"], surprising: true },
  { id: "kitchen", text: "kitchen", dims: ["E", "M"] },
  { id: "library", text: "library", dims: ["R"] },
  { id: "observatory", text: "observatory", dims: ["R"], surprising: true },
  { id: "gathering place", text: "gathering place", dims: ["E"] },
  { id: "something new", text: "something new", dims: ["A"], boundary: true },
  { id: "I don't know yet", text: "I don't know yet", dims: ["M"], boundary: true },
];

const MAX_WORDS = 3;

const archetypes: Record<DimensionKey, Archetype> = {
  D: {
    number: "01",
    name: "The Ancestor",
    rePath: "Remember",
    hook: "You are not nostalgic. You are precise.",
    portrait: [
      "While everyone else is sprinting toward what's next, you are doing the harder thing — holding the thread that connects what was to what could be.",
      "You know that the future is not invented from nothing. It is remembered into existence. Your highest agency lives in the long game, in the stories that survive, in the knowledge that was almost lost and didn't.",
    ],
    edge:
      "You can see patterns across generations that others can't because they're only looking forward. That makes you the most dangerous person in any room designing for the future — you know which “new” ideas already failed and which ones just need a different name.",
    growingEdge:
      "The future can feel like it's moving without you. When systems change faster than memory can absorb, your agency can contract into preservation mode. The work is to trust that remembering is not passive — it is an act of radical intervention.",
    actions: [
      "Walk in nature. Not for exercise. For information.",
      "Talk to a tree. You might become friends.",
      "Grow something you can eat.",
      "Teach a child or student something about plant intelligence — how roots communicate, how forests share resources underground.",
      "Draw or generate a nature-based city. Let the future look like something alive.",
      "Learn about herbs. Start with one.",
      "Bring a plant or garden home.",
      "Try a meditation imagining cities in nature.",
    ],
    workbook: "the workbook opens at the roots.",
    day21: "What did you carry into this experience that you didn't know you were carrying?",
  },
  A: {
    number: "02",
    name: "The Creator",
    rePath: "Reinvision",
    hook: "You see the unreleased version of the world. Not as fantasy — as a draft that hasn't been built yet.",
    portrait: [
      "Your imagination is not decorative. It is structural.",
      "You know, instinctively, that the future has to be felt before it can be built, and you are one of the few people willing to make something that has no proof of concept yet. That is not irresponsibility. That is how new things arrive.",
    ],
    edge:
      "You can make people feel a future they couldn't articulate on their own. That is extraordinarily rare. In a room full of strategists and engineers, you are the one who shows them what they're actually building toward — and sometimes that changes everything.",
    growingEdge:
      "Creation without ground can float. Your agency sometimes lives so far ahead of the present that it's hard to land. The work is not to slow your imagination down — it's to build one more bridge between the vision and the Tuesday morning version of it.",
    actions: [
      "Add one act of beauty to your day. Not as decoration. As practice.",
      "Wear the outfit that makes you feel like your higher self. Do it on a Tuesday.",
      "Curate your digital spaces like galleries for joy — what you see shapes what you can imagine.",
      "Build with color, teach with story, code with rhythm. Let form carry the message.",
      "Paint your workspace. Plant something that blooms. Make where you work feel like somewhere worth working.",
    ],
    workbook: "the workbook opens at the image.",
    day21: "What did you imagine during this experience that you're still thinking about?",
  },
  R: {
    number: "03",
    name: "The Architect",
    rePath: "Retrace",
    hook: "You are the one who figures out how. Not in the boring way — in the way that actually matters.",
    portrait: [
      "You believe, with evidence, that broken systems can be redesigned. That technology built wrong can be rebuilt right.",
      "That the path forward is not always forward — sometimes you retrace the steps to find where the wrong turn happened, and you fix it there. Your agency lives in structure. In the blueprint. In the thing that still works after you leave the room.",
    ],
    edge:
      "You can hold complexity without collapsing it. When everyone else is overwhelmed by how broken something is, you are already sketching the intervention. You don't just identify the problem — you produce the thing that solves it, and it passes inspection.",
    growingEdge:
      "The system can become the ceiling. Your strength is redesigning what exists, which means you sometimes under-invest in imagining what has never existed. The work is to let the blueprint get weird before you make it buildable.",
    actions: [
      "Explore a tool that helps you capture or organize your family's stories — whatever method feels right for you.",
      "Bring an ethical technology curriculum to your organization. Or ask why there isn't one.",
      "Meditate on living in harmony with nature and technology. Not as opposites. As collaborators.",
      "Support transparent, open data sharing — one concrete way, this week.",
      "Find one technology your community uses that causes more harm than good. Research one existing alternative. Share it with three people as a real option.",
    ],
    workbook: "the workbook opens at the mechanism.",
    day21: "What did this experience show you that you want to rebuild?",
  },
  M: {
    number: "04",
    name: "The Pioneer",
    rePath: "Reclaim",
    hook: "You go first. Not because you're fearless — because you've decided that waiting for permission is its own kind of loss.",
    portrait: [
      "Your agency is the most kinetic of the five. You move before the map exists. You cross lines marked “not possible” and then turn around to hold them open for whoever's coming next.",
      "Your deepest orientation is toward abundance — you actually believe there is enough, and you are willing to bet your next move on that belief.",
    ],
    edge:
      "You create permission by existing. When you move, people around you discover they can move too. That is a specific and irreplaceable kind of leadership — not the kind that stands at the front of the room, but the kind that makes the room larger just by being in it.",
    growingEdge:
      "Pioneers can get lonely at the frontier. Moving fast and first means sometimes you're building in a field where no one has caught up yet. The work is not to slow down — it's to build the signal flare into the work itself, so people know where to find you.",
    actions: [
      "Write “money is love” on your checks.",
      "Before your next decision, ask: Is this mutually beneficial for all parties?",
      "Grow something and give it away. No strings.",
      "Offer a gift with nothing expected in return.",
      "Ask someone: How can I help?",
      "Ask for help. That one counts too.",
      "Share a harvest, a meal, or a skill with a neighbor.",
      "Read Robin Wall Kimmerer's The Serviceberry — the whole economy reimagined in one small fruit.",
      "Notice one moment this week where you already have enough. Write it down.",
    ],
    workbook: "the workbook opens at the threshold.",
    day21: "What did you claim during this experience that you're not giving back?",
  },
  E: {
    number: "05",
    name: "The Unifier",
    rePath: "Reembody",
    hook: "You know something the other four archetypes sometimes forget: none of it works alone.",
    portrait: [
      "Your agency is relational by nature — not because you can't operate independently, but because you have seen, over and over, that the futures worth building require more than one nervous system in the room.",
      "You are the one who makes sure the table is large enough. Who notices who isn't there. Who turns a good idea into a shared one without losing what made it good.",
    ],
    edge:
      "You can hold a room. Not perform for it — hold it. Make people feel seen enough to say the true thing instead of the safe thing. That is the precondition for every breakthrough that actually lasts, and it is vanishingly rare.",
    growingEdge:
      "Belonging can become burden. When you are the one who always makes space for others, the question of who makes space for you can go unanswered for a long time. The work is to build the table and then sit at it — as a participant, not just the host.",
    actions: [
      "Next time you feel road rage, pause and ask: What if this were someone I loved?",
      "Message a friend right now: “Hey — I was just thinking about you. Sending love.” Don't wait for a reason.",
      "Meditate on being held in a bubble of unconditional love. Let yourself receive it before you give it.",
    ],
    workbook: "the workbook opens at the circle.",
    day21: "Who did you feel belonging with during this experience, and what does that make possible?",
  },
};

// The quiz is one linear sequence of steps: five sliders, then the five Re questions.
type Step =
  | { kind: "baseline"; index: number }
  | { kind: "inheritance" }
  | { kind: "letter" }
  | { kind: "broken-domain" }
  | { kind: "broken-future" }
  | { kind: "connection" }
  | { kind: "block" };

const steps: Step[] = [
  ...baselineStatements.map((_, index) => ({ kind: "baseline" as const, index })),
  { kind: "inheritance" },
  { kind: "letter" },
  { kind: "broken-domain" },
  { kind: "broken-future" },
  { kind: "connection" },
  { kind: "block" },
];

const questionNumbers: Record<Exclude<Step["kind"], "baseline">, number> = {
  inheritance: 1,
  letter: 2,
  "broken-domain": 3,
  "broken-future": 3,
  connection: 4,
  block: 5,
};

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "REIMAGINE Future Agency Scorecard" },
      { name: "description", content: "98% of the imagination you were born with goes dormant by adulthood. Measure what's still awake — and where it wants to go." },
      { property: "og:title", content: "REIMAGINE Future Agency Scorecard" },
      { property: "og:description", content: "The future isn't the problem. We've just forgotten we can shape it." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Scorecard,
});

function reading(total: number) {
  if (total >= 51) return "Imagination awake and directional. The work now is to bring others with you.";
  if (total >= 26) return "Imagination active. Some dimensions are already lit up.";
  return "Imagination awakening. This is the beginning, not the verdict.";
}

function flexibilityScore(distinctDimensions: number) {
  if (distinctDimensions >= 4) return 5;
  if (distinctDimensions === 3) return 3;
  if (distinctDimensions === 2) return 2;
  return 0;
}

const FLODESK_FORM_ID = "667f20c617994263fd91cc85";

function FlodeskEmbed({ onSubmitted }: { onSubmitted: () => void }) {
  const containerId = `fd-form-${FLODESK_FORM_ID}`;

  useEffect(() => {
    const w = window as unknown as { fd?: ((...args: unknown[]) => void) & { q?: unknown[] } };
    if (!w.fd) {
      const queue = (...args: unknown[]) => {
        queue.q = queue.q ?? [];
        queue.q.push(args);
      };
      queue.q = [] as unknown[];
      w.fd = queue;
    }
    if (!document.querySelector("script[data-flodesk-universal]")) {
      const script = document.createElement("script");
      script.src = "https://assets.flodesk.com/universal.mjs";
      script.async = true;
      script.type = "module";
      script.setAttribute("data-flodesk-universal", "true");
      document.head.appendChild(script);
    }
    w.fd("form", { formId: FLODESK_FORM_ID, containerEl: `#${containerId}` });

    const container = document.getElementById(containerId);
    const iframe = document.createElement("iframe");
    iframe.name = `fd-target-${containerId}`;
    iframe.title = "";
    iframe.setAttribute("aria-hidden", "true");
    iframe.style.display = "none";
    let submitted = false;
    let done = false;
    iframe.addEventListener("load", () => {
      if (!submitted || done) return;
      done = true;
      onSubmitted();
    });
    container?.appendChild(iframe);
    const retarget = (event: Event) => {
      event.preventDefault();
      event.stopImmediatePropagation();
      if (submitted) return;
      submitted = true;
      const form = event.target as HTMLFormElement;
      form.setAttribute("target", iframe.name);
      form.submit();
      window.setTimeout(() => {
        if (!done) {
          done = true;
          onSubmitted();
        }
      }, 2500);
    };
    container?.addEventListener("submit", retarget, true);
    return () => container?.removeEventListener("submit", retarget, true);
  }, [containerId, onSubmitted]);

  return <div id={containerId} className="flodesk-embed" />;
}

function WordCloud({
  words,
  picked,
  onToggle,
}: {
  words: Option[];
  picked: string[];
  onToggle: (id: string) => void;
}) {
  const full = picked.length >= MAX_WORDS;
  return (
    <div className="word-cloud" role="group" aria-label={`Pick up to ${MAX_WORDS}`}>
      {words.map((word) => {
        const isPicked = picked.includes(word.id);
        return (
          <button
            type="button"
            key={word.id}
            className={`word-chip ${isPicked ? "word-chip-picked" : ""}`}
            aria-pressed={isPicked}
            disabled={full && !isPicked}
            onClick={() => onToggle(word.id)}
          >
            {word.text}
          </button>
        );
      })}
    </div>
  );
}

function ChoiceList({
  options,
  picked,
  locked,
  onPick,
}: {
  options: { id: string; text: string }[];
  picked: string | null;
  locked: boolean;
  onPick: (id: string) => void;
}) {
  return (
    <div className="answers">
      {options.map((option, index) => (
        <button
          type="button"
          key={option.id}
          className={`answer ${picked === option.id ? "answer-selected" : ""}`}
          onClick={() => onPick(option.id)}
          disabled={locked}
          aria-pressed={picked === option.id}
        >
          <span className="answer-letter">{String.fromCharCode(65 + index)}</span>
          <span>{option.text}</span>
        </button>
      ))}
    </div>
  );
}

function Scorecard() {
  const [screen, setScreen] = useState<"frame" | "setup" | "quiz" | "email" | "results">("frame");
  const [stepIndex, setStepIndex] = useState(0);
  const [advancing, setAdvancing] = useState(false);
  const [baseline, setBaseline] = useState<number[]>(() => baselineStatements.map(() => 3));
  const [inheritance, setInheritance] = useState<string[]>([]);
  const [letter, setLetter] = useState<string | null>(null);
  const [brokenDomain, setBrokenDomain] = useState<string | null>(null);
  const [brokenFuture, setBrokenFuture] = useState<FutureTier | null>(null);
  const [connection, setConnection] = useState<string | null>(null);
  const [block, setBlock] = useState<string[]>([]);

  const domain = brokenDomains.find((item) => item.id === brokenDomain);

  const result = useMemo(() => {
    // Each answered question contributes the options picked for it.
    const perQuestion: Option[][] = [
      inheritanceWords.filter((word) => inheritance.includes(word.id)),
      letterOptions.filter((option) => option.id === letter),
      brokenDomains.filter((item) => item.id === brokenDomain),
      connectionOptions.filter((option) => option.id === connection),
      blockWords.filter((word) => block.includes(word.id)),
    ];
    if (brokenFuture && brokenFuture !== "realistic") {
      perQuestion[2] = perQuestion[2]!.map((item) => ({ ...item, surprising: true }));
    }

    const tallies: Record<DimensionKey, number> = { D: 0, R: 0, E: 0, A: 0, M: 0 };
    perQuestion.flat().forEach((option) => option.dims.forEach((dim) => (tallies[dim] += 1)));

    const distinct = dimensionKeys.filter((key) => tallies[key] > 0).length;
    const flexibility = flexibilityScore(distinct);

    const boundary = perQuestion.some((picks) => picks.some((option) => option.boundary));
    const surprisingQuestions = perQuestion.filter((picks) => picks.some((option) => option.surprising)).length;
    const originality = boundary ? 5 : Math.min(4, surprisingQuestions);

    const temporality = brokenFuture ? temporalityByTier[brokenFuture] : 0;

    // Stable sort keeps D-R-E-A-M order on ties.
    const ranked = [...dimensionKeys].sort((a, b) => tallies[b] - tallies[a]);
    const topTally = Math.max(tallies[ranked[0] ?? "D"], 1);

    return {
      tallies,
      topTally,
      flexibility,
      originality,
      temporality,
      total: (flexibility + originality + temporality) * 5,
      primaryKey: ranked[0] ?? "D",
      runnerUpKey: ranked[1] ?? "R",
    };
  }, [inheritance, letter, brokenDomain, brokenFuture, connection, block]);

  const primary = archetypes[result.primaryKey];
  const runnerUp = archetypes[result.runnerUpKey];
  const baselineTotal = baseline.reduce((sum, value) => sum + value, 0);

  const next = () => {
    if (stepIndex === steps.length - 1) {
      setScreen("email");
    } else {
      setStepIndex((current) => current + 1);
    }
  };

  // Single-choice questions advance on their own after a short beat.
  const pickAndAdvance = (apply: () => void) => {
    if (advancing) return;
    apply();
    setAdvancing(true);
    window.setTimeout(() => {
      next();
      setAdvancing(false);
    }, 400);
  };

  const toggleWord = (setter: (update: (current: string[]) => string[]) => void) => (id: string) =>
    setter((current) =>
      current.includes(id) ? current.filter((word) => word !== id) : current.length < MAX_WORDS ? [...current, id] : current,
    );

  const startOver = () => {
    setBaseline(baselineStatements.map(() => 3));
    setInheritance([]);
    setLetter(null);
    setBrokenDomain(null);
    setBrokenFuture(null);
    setConnection(null);
    setBlock([]);
    setAdvancing(false);
    setStepIndex(0);
    setScreen("frame");
  };

  const share = async () => {
    const text = `My Future Agency Score is ${result.total}/75 — I'm ${primary.name}, with a current of ${runnerUp.name}. What's still awake in yours?`;
    if (navigator.share) {
      await navigator.share({ title: "My Future Agency Score", text, url: window.location.href }).catch(() => undefined);
      return;
    }
    await navigator.clipboard.writeText(`${text} ${window.location.href}`);
  };

  const step = steps[stepIndex];
  if (!step) return null;

  const inBaseline = step.kind === "baseline";
  const questionNumber = inBaseline ? step.index + 1 : questionNumbers[step.kind];
  const progressTotal = inBaseline ? baselineStatements.length : 5;

  return (
    <main className="scorecard-shell">
      {screen === "frame" && (
        <section className="screen intro-screen animate-screen" aria-labelledby="frame-title">
          <h1 id="frame-title" className="stat-figure">98%</h1>
          <p className="lead stat-caption">of the imagination you were born with goes dormant by adulthood.</p>
          <div className="animate-screen stat-follow" style={{ animationDelay: "1400ms" }}>
            <p className="question-title">The future isn't the problem. We've just forgotten we can shape it.</p>
            <p className="prompt">This is a tool to measure your future agency — what <em>you</em> can actually do to build the future.</p>
            <button type="button" className="primary-action" onClick={() => setScreen("setup")}>Let's find out →</button>
          </div>
        </section>
      )}

      {screen === "setup" && (
        <section className="screen intro-screen animate-screen" aria-labelledby="setup-title">
          <p className="eyebrow">Reimagine — The Future Agency Scorecard</p>
          <h1 id="setup-title" className="display-title">You were born with a vast imagination.</h1>
          <p className="question-title setup-ask">What happened?</p>
          <div className="lead">
            <p>Technology moves faster than anyone asked it to. The economy makes plans feel pointless. The news makes the future feel like something that happens to you — not something you help create.</p>
            <p>Your imagination didn't disappear. It went quiet.</p>
            <p>This scorecard measures what's still awake — and where it wants to go.</p>
          </div>
          <button type="button" className="primary-action" onClick={() => setScreen("quiz")}>Begin →</button>
          <p className="time-note">Five questions · About four minutes · All clickable · No wrong answers</p>
        </section>
      )}

      {screen === "quiz" && (
        <section key={stepIndex} className="screen question-screen animate-screen" aria-labelledby="question-title">
          <div className="progress-meta">
            <span>{inBaseline ? "Baseline instincts" : "Future Agency"}</span>
            <span>{questionNumber} / {progressTotal}</span>
          </div>
          <div className="progress-track" aria-label={`${questionNumber} of ${progressTotal}`}>
            <span className="progress-fill" style={{ width: `${(questionNumber / progressTotal) * 100}%` }} />
          </div>

          {step.kind === "baseline" && (
            <>
              <div className="question-copy">
                <p className="eyebrow">Before we begin — how true is this?</p>
                <h1 id="question-title" className="question-title">{baselineStatements[step.index]!.text}</h1>
              </div>
              <input
                type="range"
                min={1}
                max={5}
                step={1}
                className="baseline-slider"
                value={baseline[step.index]}
                aria-label="Rate from 1, not really, to 5, completely"
                aria-valuetext={`${baseline[step.index]} of 5`}
                onChange={(event) => {
                  const value = Number(event.target.value);
                  setBaseline((current) => current.map((item, index) => (index === step.index ? value : item)));
                }}
              />
              <div className="rating-labels" aria-hidden="true">
                <span>Not really</span>
                <span className="slider-value">{baseline[step.index]}</span>
                <span>Completely</span>
              </div>
              <button type="button" className="primary-action continue-action" onClick={next}>Next →</button>
            </>
          )}

          {step.kind === "inheritance" && (
            <>
              <div className="question-copy">
                <p className="eyebrow">01 — The Inheritance</p>
                <h1 id="question-title" className="question-title">You've just inherited something from an ancestor you never met.</h1>
                <p className="prompt">It's not money. It's not property.</p>
                <p className="ask">What did they leave you? Pick up to 3.</p>
              </div>
              <WordCloud words={inheritanceWords} picked={inheritance} onToggle={toggleWord(setInheritance)} />
              <button type="button" className="primary-action continue-action" disabled={inheritance.length === 0} onClick={next}>Continue →</button>
            </>
          )}

          {step.kind === "letter" && (
            <>
              <div className="question-copy">
                <p className="eyebrow">02 — The Letter</p>
                <h1 id="question-title" className="question-title">You're writing one sentence to someone who will open it in 100 years.</h1>
                <p className="ask">Which sounds most like yours?</p>
              </div>
              <ChoiceList options={letterOptions} picked={letter} locked={advancing} onPick={(id) => pickAndAdvance(() => setLetter(id))} />
            </>
          )}

          {step.kind === "broken-domain" && (
            <>
              <div className="question-copy">
                <p className="eyebrow">03 — The Broken Thing</p>
                <h1 id="question-title" className="question-title">What feels most broken right now?</h1>
                <p className="ask">Pick one.</p>
              </div>
              <ChoiceList
                options={brokenDomains}
                picked={brokenDomain}
                locked={advancing}
                onPick={(id) =>
                  pickAndAdvance(() => {
                    if (id !== brokenDomain) setBrokenFuture(null);
                    setBrokenDomain(id);
                  })
                }
              />
            </>
          )}

          {step.kind === "broken-future" && domain && (
            <>
              <div className="question-copy">
                <p className="eyebrow">03 — The Broken Thing</p>
                <h1 id="question-title" className="question-title">Now pick the future that feels most true to you.</h1>
                <p className="prompt">{domain.text}</p>
              </div>
              <ChoiceList
                options={futureTiers.map((tier) => ({ id: tier, text: domain.futures[tier] }))}
                picked={brokenFuture}
                locked={advancing}
                onPick={(id) => pickAndAdvance(() => setBrokenFuture(id as FutureTier))}
              />
            </>
          )}

          {step.kind === "connection" && (
            <>
              <div className="question-copy">
                <p className="eyebrow">04 — The Connection</p>
                <h1 id="question-title" className="question-title">You have a tool that does one thing perfectly: it connects two things that have never been connected.</h1>
                <p className="ask">Which connection excites you most?</p>
              </div>
              <ChoiceList options={connectionOptions} picked={connection} locked={advancing} onPick={(id) => pickAndAdvance(() => setConnection(id))} />
            </>
          )}

          {step.kind === "block" && (
            <>
              <div className="question-copy">
                <p className="eyebrow">05 — The Empty Block</p>
                <h1 id="question-title" className="question-title">There's an abandoned block in your city.</h1>
                <p className="prompt">No budget. No rules. No limits.</p>
                <p className="ask">What do you build? Pick up to 3 words that pull you most.</p>
              </div>
              <WordCloud words={blockWords} picked={block} onToggle={toggleWord(setBlock)} />
              <button type="button" className="primary-action continue-action" disabled={block.length === 0} onClick={next}>Continue →</button>
            </>
          )}

          <div className="nav-row">
            <button
              type="button"
              className="circle-action"
              aria-label="Back"
              disabled={advancing}
              onClick={() => (stepIndex === 0 ? setScreen("setup") : setStepIndex((current) => current - 1))}
            >
              <span aria-hidden="true">←</span>
            </button>
          </div>
        </section>
      )}

      {screen === "email" && (
        <section className="screen email-screen animate-screen" aria-labelledby="email-title">
          <p className="eyebrow">Your result is ready</p>
          <h1 id="email-title" className="lead email-title">Where should we send it?</h1>
          <p className="prompt email-copy">
            Your score, your archetype portrait, your hopeful action, and your path through the REIMAGINE Workbook and 21 Days will be in your inbox.
          </p>
          <FlodeskEmbed onSubmitted={() => setScreen("results")} />
          <p className="time-note">Your result also appears on screen now.</p>
          <button type="button" className="skip-action" onClick={() => setScreen("results")}>
            Skip — just show my result
          </button>
        </section>
      )}

      {screen === "results" && (
        <section className="screen results-screen animate-screen" aria-labelledby="results-title">
          <p className="eyebrow">Your Future Agency Score</p>
          <h1 id="results-title" className="display-title">{result.total} <span className="score-out-of">/ 75</span></h1>
          <p className="result-note">{reading(result.total)}</p>
          <p className="score-breakdown">
            Flexibility {result.flexibility}/5 · Originality {result.originality}/5 · Temporality {result.temporality}/5 · Baseline {baselineTotal}/25
          </p>

          <div className="result-bars">
            {dimensionKeys.map((key, index) => (
              <div className="result-row" key={key}>
                <div className="result-label"><span>{dimensionNames[key].short}</span></div>
                <div className="result-track">
                  <span
                    className="result-fill"
                    style={{ width: `${(result.tallies[key] / result.topTally) * 100}%`, animationDelay: `${index * 100}ms` }}
                  />
                </div>
              </div>
            ))}
          </div>

          <p className="eyebrow">{primary.number} — {dimensionNames[result.primaryKey].full} × Re: {primary.rePath}</p>
          <h2 className="lead">You are {primary.name} —</h2>
          <p className="ask">with a current of {runnerUp.name}.</p>

          <div className="portrait">
            <p className="interpretation">{primary.hook}</p>
            {primary.portrait.map((paragraph) => (
              <p className="interpretation" key={paragraph}>{paragraph}</p>
            ))}

            <h3 className="eyebrow portrait-heading">Your edge</h3>
            <p className="interpretation">{primary.edge}</p>

            <h3 className="eyebrow portrait-heading">Your growing edge</h3>
            <p className="interpretation">{primary.growingEdge}</p>

            <h3 className="eyebrow portrait-heading">Your hopeful action — pick one this week</h3>
            <ul className="action-list">
              {primary.actions.map((action) => (
                <li key={action}>{action}</li>
              ))}
            </ul>

            <h3 className="eyebrow portrait-heading">Your Re path</h3>
            <p className="interpretation">{primary.rePath} → {primary.workbook}</p>
            <p className="prompt">Day 21 retake question: {primary.day21}</p>
          </div>

          <p className="result-note">Retake on Day 21 to measure what shifted.</p>
          <div className="result-actions">
            <button type="button" className="primary-action" onClick={share}>Share your score</button>
            <button type="button" className="secondary-action" onClick={startOver}>Start over</button>
          </div>
        </section>
      )}
    </main>
  );
}
