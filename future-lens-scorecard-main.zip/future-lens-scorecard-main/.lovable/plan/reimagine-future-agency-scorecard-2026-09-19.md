# REIMAGINE Future Agency Scorecard

## Build
- Replace the blank home screen with a mobile-first, single-flow scorecard: introduction, three questions, and results.
- Keep the experience centered and distraction-free, with progress feedback and one question visible at a time.
- Add the supplied copy exactly, full-width answer controls, delayed auto-advance, restart, and native share/copy fallback.

## Visual direction
- Create the specified deep-aubergine design system with white text, bright teal accents, Oswald display typography, and Nunito body typography.
- Add subtle, low-opacity animated liquid forms behind every screen, restrained entrance transitions, and a teal selection glow.
- Use responsive sizing and reduced-motion support so the experience remains polished on phones and desktop.

## Scoring and results
- Infer a balanced mapping from each answer to Openness, Imagination, Agency, and Activation.
- Normalize the four capacity scores into readable progress bars.
- Generate a concise profile interpretation based on the participant’s strongest dimensions.

## Validation
- Add complete page metadata.
- Check the preview at desktop and mobile sizes, verify the full quiz flow, and confirm sharing and restart states behave correctly.
