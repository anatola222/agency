import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";

type Dimension = "Openness" | "Imagination" | "Agency" | "Activation";
type Scores = Record<Dimension, number>;
type Answer = {
  label: string;
  text: string;
  scores: Partial<Scores>;
};

type Question = {
  category: string;
  number: string;
  title: string;
  prompt: string;
  answers: Answer[];
};

const dimensions: Dimension[] = ["Openness", "Imagination", "Agency", "Activation"];

const questions: Question[] = [
  {
    category: "Uncertainty",
    number: "01",
    title: "The Waiting Room",
    prompt:
      "You're waiting in a doctor's office for a piece of news. The doctor is running 20 minutes late. Your imagination has arrived early. What's happening in your mind?",
    answers: [
      { label: "A", text: "My brain has already written the worst-case scenario. It's quite detailed.", scores: { Imagination: 2 } },
      { label: "B", text: "I'm going over what I know and trying to stay practical.", scores: { Agency: 2, Activation: 1 } },
      { label: "C", text: "No news is just no news. I'll know when I know.", scores: { Openness: 2, Agency: 1 } },
      { label: "D", text: "My mind wanders through a few possibilities, but I don't get too attached to any one of them.", scores: { Openness: 2, Imagination: 2 } },
    ],
  },
  {
    category: "Uncertainty",
    number: "02",
    title: "A Small Plot Twist",
    prompt:
      "Your plans for the next six months suddenly change. Nothing catastrophic — but the path you thought you were on is no longer available. Where does your mind go first?",
    answers: [
      { label: "A", text: "Oh no. What am I going to do now?", scores: {} },
      { label: "B", text: "I start figuring out how to get as close to the original plan as possible.", scores: { Agency: 2, Activation: 2 } },
      { label: "C", text: "I start looking around. What other options do I have?", scores: { Openness: 2, Agency: 1 } },
      { label: "D", text: "Part of me wonders whether there's an entirely different possibility I hadn't considered before.", scores: { Openness: 2, Imagination: 2 } },
    ],
  },
  {
    category: "Community",
    number: "03",
    title: "The Empty Lot",
    prompt:
      "The sad little empty lot in your neighborhood is suddenly yours. You can't sell it — you have to turn it into something people around you would actually love. What do you see?",
    answers: [
      { label: "A", text: "Umm... parking?", scores: { Activation: 1 } },
      { label: "B", text: "Clean it up, add some trees and somewhere to sit.", scores: { Agency: 1, Activation: 2 } },
      { label: "C", text: "Garden! Food! Music! Kids! Art! Markets! Somewhere neighbors actually know each other!", scores: { Imagination: 2, Agency: 1, Activation: 2 } },
      { label: "D", text: "I start imagining something my neighborhood doesn't even have a name for yet.", scores: { Openness: 2, Imagination: 2 } },
    ],
  },
  {
    category: "Imagination",
    number: "04",
    title: "The Unfinished Sentence",
    prompt:
      "Someone at dinner says, “Wouldn't it be amazing if…” and then gets distracted and never finishes. The sentence just hangs there in the air. What do you do with it?",
    answers: [
      { label: "A", text: "Honestly? I probably don't notice. The conversation moves on.", scores: {} },
      { label: "B", text: "I ask them to finish it — now I'm curious.", scores: { Openness: 1, Activation: 1 } },
      { label: "C", text: "I finish it for them, out loud, three different ways.", scores: { Imagination: 2, Activation: 1 } },
      { label: "D", text: "It follows me home. I'm still finishing it days later.", scores: { Imagination: 2, Openness: 1 } },
    ],
  },
  {
    category: "Agency",
    number: "05",
    title: "The Blank Saturday",
    prompt:
      "A completely free Saturday appears on your calendar. No obligations, no errands, no one expecting you anywhere. By noon, where are you?",
    answers: [
      { label: "A", text: "Still deciding. That much freedom is almost stressful.", scores: {} },
      { label: "B", text: "Doing the thing I never have time for — I planned this weeks ago.", scores: { Agency: 2, Activation: 2 } },
      { label: "C", text: "Seeing where the day takes me. Wandering is the point.", scores: { Openness: 2 } },
      { label: "D", text: "Starting something new — a project, a recipe, a tiny adventure — just to see.", scores: { Activation: 2, Imagination: 1 } },
    ],
  },
  {
    category: "Activation",
    number: "06",
    title: "The Good Idea at 2 A.M.",
    prompt:
      "You wake at 2 a.m. with a genuinely good idea. It glows in the dark. What has happened to it by the following week?",
    answers: [
      { label: "A", text: "It was gone by morning. They never survive the night.", scores: { Imagination: 1 } },
      { label: "B", text: "I wrote it down. It lives in a very good notebook, with the others.", scores: { Imagination: 1, Agency: 1 } },
      { label: "C", text: "I told someone about it — saying it out loud made it realer.", scores: { Openness: 1, Activation: 1 } },
      { label: "D", text: "I'd already taken the first small step before the weekend.", scores: { Activation: 2, Agency: 2 } },
    ],
  },
  {
    category: "Community",
    number: "07",
    title: "The Knock at the Door",
    prompt:
      "A neighbor you barely know knocks and asks for help with a project you've never tried. Your evening happens to be free. What's your honest first thought?",
    answers: [
      { label: "A", text: "“I'm probably the wrong person for this.”", scores: {} },
      { label: "B", text: "“Sure — how hard can it be?”", scores: { Activation: 2, Openness: 1 } },
      { label: "C", text: "“Interesting. What are we actually trying to make happen here?”", scores: { Openness: 2, Agency: 1 } },
      { label: "D", text: "“I wonder if the whole street could get involved.”", scores: { Imagination: 2, Agency: 1 } },
    ],
  },
  {
    category: "Possibility",
    number: "08",
    title: "The Postcard From 2036",
    prompt:
      "A postcard arrives from you, ten years from now. It's one sentence long, and you don't get to know anything else. What do you hope it says?",
    answers: [
      { label: "A", text: "“Everything turned out fine.” Honestly, that would be enough.", scores: { Agency: 1 } },
      { label: "B", text: "“You're not going to believe what we built.”", scores: { Activation: 2, Agency: 1 } },
      { label: "C", text: "“It was nothing like we planned — and better.”", scores: { Openness: 2, Imagination: 1 } },
      { label: "D", text: "“You were right to imagine bigger.”", scores: { Imagination: 2, Openness: 1 } },
    ],
  },
];

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "REIMAGINE Future Agency Scorecard" },
      { name: "description", content: "Discover how openness, imagination, agency, and activation shape how you meet the future." },
      { property: "og:title", content: "REIMAGINE Future Agency Scorecard" },
      { property: "og:description", content: "How much possibility can you see—and what do you do with it?" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Scorecard,
});

function AmbientBackground() {
  return (
    <div className="ambient" aria-hidden="true">
      <span className="blob blob-one" />
      <span className="blob blob-two" />
      <span className="blob blob-three" />
    </div>
  );
}

function EmptyScores(): Scores {
  return { Openness: 0, Imagination: 0, Agency: 0, Activation: 0 };
}

function splitPrompt(prompt: string) {
  const sentences = prompt.match(/[^.?!]+[.?!]?/g)?.map((part) => part.trim()).filter(Boolean) ?? [prompt];
  const ask = sentences.length > 1 ? sentences[sentences.length - 1]! : "";
  const body = ask ? sentences.slice(0, -1) : sentences;
  const scene = body.slice(0, Math.max(1, body.length - 1)).join(" ");
  const aside = body.length > 1 ? body.slice(-1).join(" ") : "";
  return { scene, aside, ask };
}

const FLODESK_FORM_ID = "667f20c617994263fd91cc85";

function FlodeskEmbed({ onSubmitted }: { onSubmitted: () => void }) {
  const containerId = `fd-form-${FLODESK_FORM_ID}`;

  useEffect(() => {
    const w = window as unknown as { fd?: ((...args: unknown[]) => void) & { q?: unknown[] } };
    if (!w.fd) {
      const queue = (...args: unknown[]) => {
        queue.q = queue.q ?? [];
        queue.q.push(args);
      };
      queue.q = [] as unknown[];
      w.fd = queue;
    }
    if (!document.querySelector("script[data-flodesk-universal]")) {
      const script = document.createElement("script");
      script.src = "https://assets.flodesk.com/universal.mjs";
      script.async = true;
      script.type = "module";
      script.setAttribute("data-flodesk-universal", "true");
      document.head.appendChild(script);
    }
    w.fd("form", { formId: FLODESK_FORM_ID, containerEl: `#${containerId}` });

    const container = document.getElementById(containerId);
    const iframe = document.createElement("iframe");
    iframe.name = `fd-target-${containerId}`;
    iframe.title = "";
    iframe.setAttribute("aria-hidden", "true");
    iframe.style.display = "none";
    let submitted = false;
    let done = false;
    iframe.addEventListener("load", () => {
      if (!submitted || done) return;
      done = true;
      onSubmitted();
    });
    container?.appendChild(iframe);
    const retarget = (event: Event) => {
      event.preventDefault();
      event.stopImmediatePropagation();
      if (submitted) return;
      submitted = true;
      const form = event.target as HTMLFormElement;
      form.setAttribute("target", iframe.name);
      form.submit();
      window.setTimeout(() => {
        if (!done) {
          done = true;
          onSubmitted();
        }
      }, 2500);
    };
    container?.addEventListener("submit", retarget, true);
    return () => container?.removeEventListener("submit", retarget, true);
  }, [containerId, onSubmitted]);

  return <div id={containerId} className="flodesk-embed" />;
}

function Scorecard() {
  const [screen, setScreen] = useState<"intro" | "quiz" | "email" | "results">("intro");
  const [questionIndex, setQuestionIndex] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [scores, setScores] = useState<Scores>(EmptyScores);

  const results = useMemo(() => {
    const max = Math.max(...dimensions.map((dimension) => scores[dimension]), 1);
    return dimensions.map((dimension) => ({
      dimension,
      value: Math.round((scores[dimension] / max) * 100),
    }));
  }, [scores]);

  const profile = useMemo(() => {
    const ordered = [...dimensions].sort((a, b) => scores[b] - scores[a]);
    const primary: Dimension = ordered[0] ?? "Openness";
    const secondary: Dimension = ordered[1] ?? "Imagination";
    const descriptions: Record<Dimension, string> = {
      Openness: "You make room for uncertainty without rushing to close it down.",
      Imagination: "You naturally reach beyond the obvious and notice possibilities others may miss.",
      Agency: "You look for where your choices can influence what happens next.",
      Activation: "You turn ideas into movement, preferring a useful first step over a perfect plan.",
    };
    return `${descriptions[primary]} ${descriptions[secondary]} Together, ${primary.toLowerCase()} and ${secondary.toLowerCase()} are the strongest signals in how you currently meet the future.`;
  }, [scores]);

  const chooseAnswer = (answer: Answer) => {
    if (selected) return;
    setSelected(answer.label);
    setScores((current) => {
      const next = { ...current };
      dimensions.forEach((dimension) => {
        next[dimension] += answer.scores[dimension] ?? 0;
      });
      return next;
    });
    window.setTimeout(() => {
      if (questionIndex === questions.length - 1) {
        setScreen("email");
      } else {
        setQuestionIndex((current) => current + 1);
      }
      setSelected(null);
    }, 400);
  };

  const startOver = () => {
    setScores(EmptyScores());
    setSelected(null);
    setQuestionIndex(0);
    setScreen("intro");
  };

  const share = async () => {
    const top = [...results].sort((a, b) => b.value - a.value)[0] ?? { dimension: "Openness", value: 0 };
    const text = `My REIMAGINE Future Agency profile is led by ${top.dimension}. Discover yours:`;
    if (navigator.share) {
      await navigator.share({ title: "My Future Agency Profile", text, url: window.location.href }).catch(() => undefined);
      return;
    }
    await navigator.clipboard.writeText(`${text} ${window.location.href}`);
  };

  const currentQuestion = questions[questionIndex];
  if (!currentQuestion) return null;

  return (
    <main className="scorecard-shell">
      <AmbientBackground />

      {screen === "intro" && (
        <section className="screen intro-screen animate-screen" aria-labelledby="intro-title">
          <p className="brand-mark">Reimagine</p>
          <h1 id="intro-title" className="display-title">The Reimagine<br />Future Agency<br />Scorecard</h1>
          <span className="hair-rule" aria-hidden="true" />
          <p className="lead">What happens when your imagination meets the future?</p>
          <div className="intro-copy">
            <p><em>The future is uncertain. But here's something less obvious: what does your mind do with that uncertainty? Through a series of everyday situations and strange plot twists, this scorecard explores four capacities that shape how you meet what's next: Openness. Imagination. Agency. Activation.</em></p>
            <p><em>There are no good or bad scores. Just a question: How much possibility can you see—and what do you do with it?</em></p>
          </div>
          <button type="button" className="primary-action" onClick={() => setScreen("quiz")}>Begin <span aria-hidden="true">→</span></button>
          <p className="time-note">8 questions · About 4 minutes</p>
          <p className="footer-mark">A more human future is a creative act.</p>
        </section>
      )}

      {screen === "quiz" && (
        <section key={questionIndex} className="screen question-screen animate-screen" aria-labelledby="question-title">
          <div className="progress-meta">
            <span>Future Agency</span>
            <span>{questionIndex + 1} / {questions.length}</span>
          </div>
          <div className="progress-track" aria-label={`Question ${questionIndex + 1} of ${questions.length}`}>
            <span className="progress-fill" style={{ width: `${((questionIndex + 1) / questions.length) * 100}%` }} />
          </div>
          <div className="question-copy">
            <p className="question-number">{currentQuestion.number}</p>
            <p className="category">{currentQuestion.title}</p>
            <h1 id="question-title" className="question-title">{splitPrompt(currentQuestion.prompt).scene}</h1>
            {splitPrompt(currentQuestion.prompt).aside && (
              <p className="prompt">{splitPrompt(currentQuestion.prompt).aside}</p>
            )}
            <p className="ask">{splitPrompt(currentQuestion.prompt).ask}</p>
          </div>

          <div className="answers">
            {currentQuestion.answers.map((answer) => (
              <button
                type="button"
                key={answer.label}
                className={`answer ${selected === answer.label ? "answer-selected" : ""}`}
                onClick={() => chooseAnswer(answer)}
                disabled={selected !== null}
              >
                <span className="answer-letter">{answer.label}</span>
                <span>{answer.text}</span>
              </button>
            ))}
          </div>
          <div className="nav-row">
            <button
              type="button"
              className="circle-action"
              aria-label="Previous question"
              disabled={questionIndex === 0 || selected !== null}
              onClick={() => setQuestionIndex((current) => Math.max(0, current - 1))}
            >
              <span aria-hidden="true">←</span>
            </button>
            <p className="category" style={{ margin: 0 }}>{currentQuestion.category}</p>
          </div>
        </section>
      )}

      {screen === "email" && (
        <section className="screen email-screen animate-screen" aria-labelledby="email-title">
          <p className="eyebrow">Your profile is ready</p>
          <h1 id="email-title" className="lead email-title">See where you stand.</h1>
          <p className="prompt email-copy">Leave your email to get your full Future Agency scorecard — and what's possible from here.</p>
          <FlodeskEmbed onSubmitted={() => setScreen("results")} />
          <button type="button" className="skip-action" onClick={() => setScreen("results")}>
            Skip — just show my results
          </button>
        </section>
      )}


      {screen === "results" && (
        <section className="screen results-screen animate-screen" aria-labelledby="results-title">
          <p className="eyebrow">The future, according to you</p>
          <h1 id="results-title" className="lead result-title">Your future agency profile.</h1>
          <div className="result-bars">
            {results.map(({ dimension, value }, index) => (
              <div className="result-row" key={dimension}>
                <div className="result-label"><span>{dimension}</span><span>{value}</span></div>
                <div className="result-track"><span className="result-fill" style={{ width: `${value}%`, animationDelay: `${index * 100}ms` }} /></div>
              </div>
            ))}
          </div>
          <p className="interpretation">{profile}</p>
          <p className="result-note">This isn't a fixed identity. It's a snapshot of the capacities you reached for today.</p>
          <div className="result-actions">
            <button type="button" className="primary-action" onClick={share}>Share your score</button>
            <button type="button" className="secondary-action" onClick={startOver}>Start over</button>
          </div>
        </section>
      )}
    </main>
  );
}
