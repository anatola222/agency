# Future Lens Scorecard

Here's a thorough prompt for your Lovable vibe coding session:

---

**REIMAGINE Future Agency Scorecard — Lovable Build Prompt**

Build a mobile-first quiz app called the **REIMAGINE Future Agency Scorecard**.

---

**Visual Identity**
- Background: warm dark purple (`#1E0E2E` or similar deep aubergine)
- Font for body/UI: Neutraface Text (import via Google Fonts or use `'Nunito'` as fallback if unavailable — clean geometric sans)
- Font for headlines/question titles: Oswald (as a stand-in for Osiris — bold display, all-caps or large weight)
- Text color: white (`#FFFFFF`)
- Accent color: bright teal-cyan (`#00D4CC` or `#0AFFEF`)
- Buttons: large, full-width, white background with dark purple text — pill-shaped, generous padding
- Minimal, clean, lots of breathing room

**Background Animation**
- Subtle slow-moving liquid/lava-lamp blobs in background — very low opacity (5–10%), slightly lighter purple tones — smooth, organic, looping. Use CSS `@keyframes` with `border-radius` morphing and slow `transform: translate` on 2–3 blobs. Should feel ambient, not distracting.

---

**App Structure**

**Screen 1 — Intro**
Title (Oswald/display font, large): `THE REIMAGINE FUTURE AGENCY SCORECARD`
Subtitle (Neutraface/body): `What happens when your imagination meets the future?`
Short intro copy (small, muted white):
> *The future is uncertain. But here's something less obvious: what does your mind do with that uncertainty? Through a series of everyday situations and strange plot twists, this scorecard explores four capacities that shape how you meet what's next: Openness. Imagination. Agency. Activation.*
> *There are no good or bad scores. Just a question: How much possibility can you see—and what do you do with it?*

CTA Button (large white pill): `Begin →`

---

**Screen 2–N — Questions**
Show one question at a time. Progress indicator at top (teal line or dots).

Each question has:
- A **category label** in teal, small caps above the question (e.g. `UNCERTAINTY`, `COMMUNITY`)
- A **question number + evocative title** in display font (e.g. `01 — THE WAITING ROOM`)
- The **question text** in body font, medium size
- **4 answer options** as large white pill buttons (A, B, C, D), stacked vertically, full width
- On selection: selected button turns teal with dark text, slight scale animation, then auto-advances after 400ms

**Questions to include:**

> **01 — THE WAITING ROOM** *(Category: UNCERTAINTY)*
> You're waiting in a doctor's office for a piece of news. The doctor is running 20 minutes late. Your imagination has arrived early. What's happening in your mind?
> A. My brain has already written the worst-case scenario. It's quite detailed.
> B. I'm preparing for the worst while leaving a little room for the best.
> C. No news is just no news. I'll know when I know.
> D. My mind wanders through a few possibilities, but I don't get too attached to any one of them.

> **02 — A SMALL PLOT TWIST** *(Category: UNCERTAINTY)*
> Your plans for the next six months suddenly change. Nothing catastrophic — but the path you thought you were on is no longer available. Where does your mind go first?
> A. Oh no. What am I going to do now?
> B. I start figuring out how to get as close to the original plan as possible.
> C. I start looking around. What other options do I have?
> D. Part of me wonders whether there's an entirely different possibility I hadn't considered before.

> **03 — THE EMPTY LOT** *(Category: COMMUNITY)*
> The sad little empty lot in your neighborhood is suddenly yours. You can't sell it — you have to turn it into something people around you would actually love. What do you see?
> A. Umm... parking?
> B. Clean it up, add some trees and somewhere to sit.
> C. Garden! Food! Music! Kids! Art! Markets! Somewhere neighbors actually know each other!
> D. I start imagining something my neighborhood doesn't even have a name for yet.

---

**Screen — Results**
After all questions, show a results screen with:
- Headline (display font): `YOUR FUTURE AGENCY PROFILE`
- A simple visual breakdown of the four dimensions: **Openness · Imagination · Agency · Activation** — shown as four teal accent bars or a minimal radial/circle display
- A short 2–3 sentence interpretation paragraph based on their answer patterns
- Two white pill buttons: `Share Your Score` and `Start Over`

---

**Motion & Feel**
- Smooth page transitions (fade or slide up)
- Teal accent glow on selected answers
- The liquid background blobs should be always present, very subtle
- No clutter, no sidebars, no nav chrome — full screen, centered content, max-width ~480px on desktop

---

That should give Lovable everything it needs. Want me to also draft the scoring logic (which answers map to which of the four capacities) or the results copy for each profile type?

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/8b3107bc-af18-4b0b-905c-a9d446f76b4c).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
